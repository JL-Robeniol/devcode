package com.example.faq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
        SqlliteDatabase database;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);
                final EditText checkemail=findViewById(R.id.cemail);
                final EditText checkpass=findViewById(R.id.cpassword);
                Button btnsignin=findViewById(R.id.signin);
                Button btncreate=findViewById(R.id.Creacc);

                btncreate.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                Intent intent = new  Intent( MainActivity.this, signup.class);
                                startActivity(intent);
                        }
                });
                btnsignin.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                                String email = checkemail.getText().toString();
                                String pass = checkpass.getText().toString();

                                if (email.isEmpty()||pass.isEmpty()) {
                                        Toast.makeText(MainActivity.this, "Please Enter Username and Password", Toast.LENGTH_SHORT).show();
                                }else {
                                        Boolean checkuserpass =database.checkemailpassword(email,pass);
                                        if (checkuserpass ==true){

                                                Toast.makeText(MainActivity.this, "Sign in Successful!", Toast.LENGTH_SHORT).show();
                                                Intent intent = new Intent(getApplicationContext(),homescreen.class);
                                                startActivity(intent);
                                        }
                                        else {
                                                Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                                        }
                                }

                        }
                });

        }
}