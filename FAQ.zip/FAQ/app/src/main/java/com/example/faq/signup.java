package com.example.faq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class signup extends AppCompatActivity {

    EditText lname, fname, pnum , addr , mail, pass;
    Button regs;
    SqlliteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();
        database= new SqlliteDatabase(this);
        lname=findViewById(R.id.Plastname);
        fname=findViewById(R.id.Plastname);
        pnum=findViewById(R.id.phonenumber);
        addr=findViewById(R.id.address);
        mail=findViewById(R.id.email);
        pass=findViewById(R.id.Password);
        regs=findViewById(R.id.Creaddacc);

        regs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String lastname = lname.getText().toString();
                String firstname= fname.getText().toString();
                String Pnumber = pnum.getText().toString();
                String Address = addr.getText().toString();
                String email = mail.getText().toString();
                String password = pass.getText().toString();
                if ( lastname.equals("")||firstname.equals("")||Pnumber.equals("")||Address.equals("")||
                        email.equals("")||password.equals(""))
                    Toast.makeText(signup.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                else {
                        Boolean checkuser = database.checkemail(email);
                        if (checkuser==false){
                            Boolean insert = database.insertData(lastname, firstname, Pnumber, Address,email, password);
                            if (insert==true){
                                Toast.makeText(signup.this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
                                Intent int1 = new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(int1);
                            }else{
                                Toast.makeText(signup.this, "Register Failed!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(signup.this, "Email already exist!", Toast.LENGTH_SHORT).show();
                        }
                }

            }
        });







    }
}