package com.example.faq;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.widget.Button;

public class SqlliteDatabase extends SQLiteOpenHelper {
    public static final String DB_name = "register.db";
    public  SqlliteDatabase(Context context){
        super(context,"register.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE users (Lastname Text, Firstname Text, Phonenumber Text, Address Text, Email Text PRIMARY KEY, Password Text )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        database.execSQL("DROP TABLE IF EXISTS users");
    }
    public boolean insertData(String Lastname, String Firstname, String Phonenumber, String Address, String Email, String Password){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Lastname",Lastname);
        contentValues.put("Firstname", Firstname);
        contentValues.put("Phonenumber", Phonenumber);
        contentValues.put("Address", Address);
        contentValues.put("Email", Email);
        contentValues.put("Password", Password);

        long result = database.insert("users", null, contentValues);

        if (result==-1) return false;
        else
            return true;
        }
    public Boolean checkemail (String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where email = ?", new String[]{email});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public Boolean checkemailpassword (String Email, String Password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery( "select * from users where Email = ? and Password = ?", new String[] {Email,Password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public Cursor getdata ( ) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users ", null);
        return cursor;
    }


}
